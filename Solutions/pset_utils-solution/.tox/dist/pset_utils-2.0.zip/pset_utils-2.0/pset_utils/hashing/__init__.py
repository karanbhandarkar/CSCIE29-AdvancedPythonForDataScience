# encoding: utf-8
import hashlib

def hash_str(some_val, salt=''):
    """Hash a string
    :param some_val: str to write
    :param salt: salt to append to string
    :returns the .digest() of the hash
    Example::
        hash_str('world!', salt='hello, ').hex()[:6] == '68e656'
    """
    m = hashlib.sha256()
    try:
        if isinstance(salt, str):   
            m.update(str.encode(salt))
        else:
            m.update(salt)
    except AttributeError:
        raise

    m.update(str.encode(some_val))

    return m.digest()
