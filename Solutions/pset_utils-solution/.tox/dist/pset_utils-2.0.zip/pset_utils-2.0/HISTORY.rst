=======
History
=======

0.1.0 (2018-09-17)
------------------

* First release on PyPI.
