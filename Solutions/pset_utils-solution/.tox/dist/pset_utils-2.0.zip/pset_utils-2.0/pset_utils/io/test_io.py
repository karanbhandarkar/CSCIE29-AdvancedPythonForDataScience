# encoding: utf-8
import contextlib
import os.path
import unittest
from pset_utils.io import atomic_write

class AtomicWriteTestCase(unittest.TestCase):

    def test_atomic_write(self):
        fn = "hello.txt"
        with contextlib.suppress(FileNotFoundError):
            os.remove(fn)
        with atomic_write("hello.txt") as f:
            f.write("world!")
        self.assertTrue(os.path.isfile(fn))

    def test_contents(self):
        fn = "hello.txt"
        if os.path.isfile(fn):
            with open(fn) as f:
                fc = f.read()
                self.assertEqual(fc, "world!")


if __name__ == '__main__':
    unittest.main()
